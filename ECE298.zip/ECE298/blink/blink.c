//***************************************************************************************
//  MSP430 Blink the LED Demo - Software Toggle P1.0
//
//  Description; Toggle P1.0 by xor'ing P1.0 inside of a software loop.
//  ACLK = n/a, MCLK = SMCLK = default DCO
//
//                MSP430x5xx
//             -----------------
//         /|\|              XIN|-
//          | |                 |
//          --|RST          XOUT|-
//            |                 |
//            |             P1.0|-->LED
//
//  Texas Instruments, Inc
//  July 2013
//***************************************************************************************

#include "LcdDriver/Sharp96x96.h"
#include <msp430.h>


Graphics_Context g_sContext;

void main(void) {
    uint16_t gie;

    WDTCTL = WDTPW | WDTHOLD;               // Stop watchdog timer
    PM5CTL0 &= ~LOCKLPM5;                   // Disable the GPIO power-on default high-impedance mode
                                            // to activate previously configured port settings
    P1DIR |= 0x01;                          // Set P1.0 to output direction

    boardInit();
        clockInit();
        timerInit();

        // Set up the LCD
        Sharp96x96_initDisplay();

        /*
         * Disable the GPIO power-on default high-impedance mode to activate
         * previously configured port settings
         */

        PMM_unlockLPM5();

        __enable_interrupt();


    Graphics_initContext(&g_sContext, &g_sharp96x96LCD);
        Graphics_setForegroundColor(&g_sContext, ClrBlack);
        Graphics_setBackgroundColor(&g_sContext, ClrWhite);
        Graphics_setFont(&g_sContext, &g_sFontFixed6x8);
        Graphics_clearDisplay(&g_sContext);
        // Store current GIE state
        gie = __get_SR_register() & GIE;
        __disable_interrupt();
        // Flush Buffer to LCD
        Graphics_flushBuffer(&g_sContext);
        // Restore original GIE state
        __bis_SR_register(gie);

        // Intro Screen
        Graphics_drawStringCentered(&g_sContext,
                                    "How to use",
                                    AUTO_STRING_LENGTH,
                                    48,
                                    15,
                                    TRANSPARENT_TEXT);

        gie = __get_SR_register() & GIE;
            __disable_interrupt();
            // Flush Buffer to LCD
            Graphics_flushBuffer(&g_sContext);
            // Restore original GIE state
            __bis_SR_register(gie);
    /*
    for(;;) {
        volatile unsigned int i;            // volatile to prevent optimization

        P1OUT ^= 0x01;                      // Toggle P1.0 using exclusive-OR

        i = 10000;                          // SW Delay
        do i--;
        while(i != 0);
    }
    */
}
